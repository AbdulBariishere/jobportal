package com.task.jobportal.serviceImpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.task.jobportal.entity.UserAccount;
import com.task.jobportal.repository.UserAccountRepository;
import com.task.jobportal.service.UserAccountService;

@Service
public class UserAccountServiceImpl implements UserAccountService{

	public UserAccount save(UserAccount userAccount) {
		userAccount = userAccountRepository.save(userAccount);
		return userAccount;
	}
	
	@Autowired
	UserAccountRepository userAccountRepository;
}
