package com.task.jobportal.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.task.jobportal.entity.BussinessStream;
import com.task.jobportal.service.BussinesStreamService;

@RestController("/bussiness_stream")
public class BussinessStreamController {

	@PostMapping(value = "/add_stream")
	public ResponseEntity<Object> add(@RequestBody BussinessStream bussinessStream,HttpServletRequest htppRequest,HttpSession httpSession){
		
		try{
			bussinessStream = bussinesStreamService.addStream(bussinessStream);
			return new ResponseEntity<Object>(bussinessStream, HttpStatus.OK);
		}catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			return new ResponseEntity<Object>(e, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		
	}
	
	@Autowired
	BussinesStreamService bussinesStreamService;
}
