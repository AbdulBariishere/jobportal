package com.task.jobportal.entity;

import java.io.Serializable;
import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@Entity
public class SeekerProfile implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="SEEKER_PROFILE_ID")
	private Long seekerProfileId;

	
	@OneToOne
    @JoinColumn(name = "ID", referencedColumnName = "ID")
	private UserAccount userAccount;
	
	
	private String firstName;
	
	private String lastName;
	
	private Double currentSalary;
	
	private String currency;
	

}
