package com.task.jobportal.service;

import com.task.jobportal.entity.SkillSet;

public interface SkillSetService {
	public SkillSet save(SkillSet skillSet);

}
