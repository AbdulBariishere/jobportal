package com.task.jobportal.service;

import com.task.jobportal.entity.SeekerProfile;

public interface SeekerProfileService {

	public SeekerProfile addSeekerProfile(SeekerProfile seekerProfile);
	
}
