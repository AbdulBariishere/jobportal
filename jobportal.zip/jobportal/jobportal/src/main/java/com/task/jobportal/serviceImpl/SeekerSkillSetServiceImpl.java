package com.task.jobportal.serviceImpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.task.jobportal.entity.SeekerSkillSet;
import com.task.jobportal.repository.SeekerSkillSetRepository;
import com.task.jobportal.service.SeekerSkillSetService;

@Service

public class SeekerSkillSetServiceImpl implements SeekerSkillSetService{
	
	public SeekerSkillSet addSeekerSkillSet(SeekerSkillSet seekerSkillSet) {
		seekerSkillSet = seekerSkillSetRepository.save(seekerSkillSet);
		return seekerSkillSet;
	}
	
	@Autowired
	SeekerSkillSetRepository seekerSkillSetRepository;

}
