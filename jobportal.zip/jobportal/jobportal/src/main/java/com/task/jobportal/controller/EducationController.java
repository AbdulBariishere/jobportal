package com.task.jobportal.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.task.jobportal.entity.EducationalDetail;
import com.task.jobportal.service.EducationalDetailService;

@RestController
@RequestMapping("/education")
public class EducationController {

	@PostMapping("/add_education")
	public ResponseEntity<Object> addEducationalDetail(EducationalDetail educationalDetail){
		try {
			educationalDetail = educationalDetailService.addEducationalDetail(educationalDetail);
	return new ResponseEntity<Object>(educationalDetail,HttpStatus.OK);
		}catch (Exception e) {
			// TODO: handle exception
			return new ResponseEntity<Object>(e,HttpStatus.INTERNAL_SERVER_ERROR);
		}
		
	
	}
	
	@Autowired
	EducationalDetailService educationalDetailService;
}
