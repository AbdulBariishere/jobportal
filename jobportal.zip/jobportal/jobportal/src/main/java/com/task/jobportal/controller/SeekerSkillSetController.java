package com.task.jobportal.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.task.jobportal.entity.SeekerSkillSet;
import com.task.jobportal.service.SeekerSkillSetService;
import com.task.jobportal.service.SkillSetService;

@RestController
@RequestMapping("/seeker_skill_set")
public class SeekerSkillSetController {

	@PostMapping("/add_seeker_skill_set")
	public ResponseEntity<Object> addSeekerSkillSet(@RequestBody SeekerSkillSet seekerSkillSet){
		try {
			seekerSkillSet = seekerSkillSetService.addSeekerSkillSet(seekerSkillSet);
			return new ResponseEntity<Object>(seekerSkillSet,HttpStatus.OK);
		}catch (Exception e) {
			// TODO: handle exception
			return new ResponseEntity<Object>(e,HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@Autowired
	SeekerSkillSetService seekerSkillSetService;
}
