package com.task.jobportal.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.task.jobportal.entity.SkillSet;
import com.task.jobportal.service.SkillSetService;

@RestController
@RequestMapping("/skill_set")
public class SkillSetController {
	@PostMapping("/add_skill_set")
	public ResponseEntity<Object> addSkillSet(@RequestBody SkillSet skillSet) {
		try {
			skillSet = skillSetService.save(skillSet);
			return new ResponseEntity<Object>(skillSet,HttpStatus.OK);
		}catch (Exception e) {
			// TODO: handle exception
			return new ResponseEntity<Object>(skillSet,HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@Autowired
	SkillSetService skillSetService;

}
