package com.task.jobportal.serviceImpl;

import java.time.LocalDate;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.task.jobportal.entity.UserType;
import com.task.jobportal.repository.UserTypeRepository;
import com.task.jobportal.service.UserTypeService;

@Service
public class UserTypeServiceImpl  implements UserTypeService{
	
	public UserType saveUserType(UserType userType) {
		userType.setCreatedOn(LocalDate.now());
		userType =	userTypeRepository.save(userType);
		return userType;
	}
	
	@Autowired
	UserTypeRepository userTypeRepository;

}
