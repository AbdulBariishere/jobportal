package com.task.jobportal.serviceImpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.task.jobportal.entity.EducationalDetail;
import com.task.jobportal.repository.EducationalDetailRepository;
import com.task.jobportal.service.EducationalDetailService;

@Service
public class EducationalDetailServiceImpl implements EducationalDetailService{
	
	public EducationalDetail addEducationalDetail(EducationalDetail educationalDetail) {
		educationalDetail =	educationalDetailRepository.save(educationalDetail);
		return educationalDetail;
	}
	
@Autowired
EducationalDetailRepository educationalDetailRepository;
}
