package com.task.jobportal.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.google.gson.Gson;
import com.task.jobportal.entity.UserType;
import com.task.jobportal.service.UserTypeService;

@RestController
@RequestMapping("/user_type")
public class UserTypeController {

@PostMapping("/add_user_type")
@ResponseBody
public ResponseEntity<Object> addType(@RequestBody UserType userType) {
	try {
		System.out.println(""+new Gson().toJson(userType));
		userType = userTypeService.saveUserType(userType);
		return new ResponseEntity<Object>(userType,HttpStatus.OK);
	}catch (Exception e) {
		return new ResponseEntity<Object>(userType,HttpStatus.INTERNAL_SERVER_ERROR);
	}
	
}

@Autowired
UserTypeService userTypeService;

}
