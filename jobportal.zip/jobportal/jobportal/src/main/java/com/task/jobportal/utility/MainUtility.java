package com.task.jobportal.utility;

import java.util.Arrays;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.function.Function;
import java.util.stream.Collectors;

public class MainUtility {
	
	public static void main(String [] args ) {
	    List<Integer> list = Arrays.asList(5, 3, 4, 1, 3, 7, 2, 9, 9, 4);
	    Set<Integer> result = new LinkedHashSet<Integer>();
	    for(int i : list) {
	    	result.add(i);
	    }

       System.out.println("result :"+result);
	}

}
