package com.task.jobportal.serviceImpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.task.jobportal.entity.ExperienceDetail;
import com.task.jobportal.repository.ExperienceDetailRepository;
import com.task.jobportal.service.ExperianceDetailService;

@Service
public class ExperianceDetailServieImpl implements ExperianceDetailService{

	public ExperienceDetail addExperianDetail(ExperienceDetail experienceDetail) {
		experienceDetail = experienceDetailRepository.save(experienceDetail);
		return experienceDetail;
		
	}
	
	@Autowired
	ExperienceDetailRepository experienceDetailRepository;
}
