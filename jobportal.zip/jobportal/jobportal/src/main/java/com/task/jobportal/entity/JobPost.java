package com.task.jobportal.entity;

import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;


@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Entity
public class JobPost {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name="JOB_POST_ID")
	private Long jobPostId;
	
	@ManyToOne
    @JoinColumn(name = "ID", referencedColumnName = "ID")
	private UserAccount userAccount;
	
	@ManyToOne
    @JoinColumn(name = "COMPANY_ID", referencedColumnName = "COMPANY_ID")
	private Company company;
	
	@ManyToOne
    @JoinColumn(name = "JOB_TYPE_ID", referencedColumnName = "JOB_TYPE_ID")
	private JobType jobType;
	
	private LocalDate createdDate;
	
	private String jobDescription;
	
	@ManyToOne
    @JoinColumn(name = "JOB_LOCATION_ID", referencedColumnName = "JOB_LOCATION_ID")
	private JobLocation jobLocation;
	
	
	private int isActive;
	
	
	
	
	
	
	
	

}
