package com.task.jobportal.serviceImpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.task.jobportal.entity.BussinessStream;
import com.task.jobportal.repository.BussinessStreamRepository;
import com.task.jobportal.service.BussinesStreamService;



@Service
public class BussinessStreamServiceImpl implements BussinesStreamService{

	public  BussinessStream addStream(BussinessStream bussinessStream) {
		bussinessStream = bussinessStreamRepository.save(bussinessStream);
		return bussinessStream;
	}
	
	@Autowired
	BussinessStreamRepository bussinessStreamRepository;
	
}
