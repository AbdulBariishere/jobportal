package com.task.jobportal.service;

import com.task.jobportal.entity.EducationalDetail;

public interface EducationalDetailService {

	public EducationalDetail addEducationalDetail(EducationalDetail educationalDetail);
}
