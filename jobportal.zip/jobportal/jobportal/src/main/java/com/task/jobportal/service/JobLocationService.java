package com.task.jobportal.service;

import org.springframework.web.bind.annotation.RequestBody;

import com.task.jobportal.entity.JobLocation;

public interface JobLocationService {

	public JobLocation addJobLocationService(@RequestBody JobLocation jobLocation);
}
