package com.task.jobportal.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.task.jobportal.entity.UserAccount;
import com.task.jobportal.service.UserAccountService;

@RestController
@RequestMapping("/user_account")
public class UserAccountController {
	
	@PostMapping("/add_user_account")
	@ResponseBody
	public ResponseEntity<Object> addUserAccount(@RequestBody UserAccount userAccount) {
		try {
		userAccount = userAccountService.save(userAccount);
		return new ResponseEntity<Object>(userAccount,HttpStatus.OK);
		}catch (Exception e) {
			return new ResponseEntity<Object>(userAccount,HttpStatus.INTERNAL_SERVER_ERROR);
			// TODO: handle exception
		}
		
	}

	@Autowired
	UserAccountService userAccountService;
}
