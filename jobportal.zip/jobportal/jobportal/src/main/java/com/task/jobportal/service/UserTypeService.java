package com.task.jobportal.service;

import com.task.jobportal.entity.UserType;

public interface UserTypeService {

	public UserType saveUserType(UserType userType);
}
