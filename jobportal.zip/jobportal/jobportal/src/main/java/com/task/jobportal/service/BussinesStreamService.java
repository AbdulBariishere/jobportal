package com.task.jobportal.service;


import com.task.jobportal.entity.BussinessStream;


public interface BussinesStreamService  {
	
	public  BussinessStream addStream(BussinessStream bussinessStream);
	
	

}
