package com.task.jobportal.entity;

import java.io.Serializable;
import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@Entity
public class ExperienceDetail  implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="EXPERIANCE_DETAIL_ID")
	private Long experianceDetailId;
	
	@ManyToOne
    @JoinColumn(name = "ID", referencedColumnName = "ID")
	private UserAccount userAccount;
	
	private Integer isCurrentJob;
	
	private LocalDate startDate;
	
	private LocalDate endDate;
	
	private String jobTitle;
	
	private String companyName;
	
	private String jobLocationCity;
	
	private String jobLocationState;
	
	private String jolocationCountry;
	
	private String description;
	
	
}
