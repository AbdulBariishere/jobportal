package com.task.jobportal.entity;

import java.io.Serializable;
import java.sql.Blob;
import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.Lob;
import javax.persistence.ManyToOne;

import com.sun.istack.NotNull;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;




@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@Entity
public class UserAccount implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="ID")
	private Long id;
	
		@ManyToOne
	    @JoinColumn(name = "USER_TYPE_ID", referencedColumnName = "USER_TYPE_ID")
	    private UserType userType;

	@NotNull
	private String name;
	@NotNull
	private String email;
	@NotNull
	private String password;
	private LocalDate dateOfBirth;
	private String gender;
	private String isActive;
	private String contactNumber;
	private LocalDate createdOn;
	 @Lob
	 private Blob image;
}
