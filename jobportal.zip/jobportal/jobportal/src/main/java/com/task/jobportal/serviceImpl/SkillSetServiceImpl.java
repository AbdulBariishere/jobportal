package com.task.jobportal.serviceImpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.task.jobportal.entity.SkillSet;
import com.task.jobportal.repository.SkillSetRepository;
import com.task.jobportal.service.SkillSetService;

@Service
public class SkillSetServiceImpl implements SkillSetService{
	public SkillSet save(SkillSet skillSet) {
		skillSet= skillSetRepository.save(skillSet);
		return skillSet;
	}
	
	@Autowired
	SkillSetRepository skillSetRepository;

}
