package com.task.jobportal.serviceImpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.task.jobportal.entity.UserLog;
import com.task.jobportal.repository.UserLogRepository;
import com.task.jobportal.service.UserLogService;

@Service
public class UserLogServiceImpl implements UserLogService {
	
	public UserLog addUserLog(UserLog userLog) {
	 userLog =	userLogRepository.save(userLog);
	 return userLog;
	}
	
	@Autowired
	UserLogRepository userLogRepository;

}
