package com.task.jobportal.serviceImpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.task.jobportal.entity.JobPost;
import com.task.jobportal.repository.JobPostRepository;
import com.task.jobportal.service.JobPostService;

@Service
public class JobPostServiceImpl implements JobPostService{

	public JobPost addJobPost(JobPost jobPost) {
		return jobPostRepository.save(jobPost);
	}
	
	@Autowired
	JobPostRepository jobPostRepository;
}
