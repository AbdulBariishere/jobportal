package com.task.jobportal.serviceImpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.task.jobportal.entity.JobLocation;
import com.task.jobportal.repository.JobLocationRepository;
import com.task.jobportal.service.JobLocationService;

@Service
public class JobLocationServiceImpl implements JobLocationService{

	
	public JobLocation addJobLocationService(JobLocation jobLocation) {
		return jobLocationRepository.save(jobLocation);
	}
	
	@Autowired
	JobLocationRepository jobLocationRepository;
}
