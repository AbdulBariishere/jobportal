package com.task.jobportal.service;

import com.task.jobportal.entity.JobPost;

public interface JobPostService {

	public JobPost addJobPost(JobPost jobPost);
}
