package com.task.jobportal.entity;

import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@Entity
@Table(name="COMPANY")
public class Company {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name="COMPANY_ID")
	public Long companyId;
	
	@ManyToOne
	 @JoinColumn(name = "BUSSINESS_STREAM_ID", referencedColumnName = "BUSSINESS_STREAM_ID")
    private BussinessStream bussinessStream;


	@Column(name="COMPANY_NAME")
	public String  companyName;
	
	@Column(name="COMPANY_DESCRIPTION")
	public String  companyDescription;
	
	@Column(name="COMPANY_WEBSITE")
	public String  companyWebsite;
	
	@Column(name="CREATED_ON")
	public LocalDate  createdOn;
	
	
	
}
