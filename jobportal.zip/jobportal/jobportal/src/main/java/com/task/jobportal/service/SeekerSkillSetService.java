package com.task.jobportal.service;

import com.task.jobportal.entity.SeekerSkillSet;

public interface SeekerSkillSetService {

	public SeekerSkillSet addSeekerSkillSet(SeekerSkillSet seekerSkillSet);
}
