package com.task.jobportal.serviceImpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.task.jobportal.entity.SeekerProfile;
import com.task.jobportal.repository.SeekerProfileRepository;
import com.task.jobportal.service.SeekerProfileService;

@Service
public class SeekerProfileServiceImpl implements SeekerProfileService{

	public SeekerProfile addSeekerProfile(SeekerProfile seekerProfile) {
		seekerProfile = seekerProfileRepository.save(seekerProfile);
		return seekerProfile;
	}
	
	@Autowired
	SeekerProfileRepository seekerProfileRepository;
}
