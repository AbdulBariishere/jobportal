package com.task.jobportal.entity;

public class JobPostSkillSet {

}
