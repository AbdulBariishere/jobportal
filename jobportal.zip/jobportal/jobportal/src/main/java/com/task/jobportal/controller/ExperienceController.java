package com.task.jobportal.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.task.jobportal.entity.ExperienceDetail;
import com.task.jobportal.service.ExperianceDetailService;

@RestController
@RequestMapping("/experience")
public class ExperienceController {

	@PostMapping("/add_experience")
	public ResponseEntity<Object> adExperiance(@RequestBody ExperienceDetail experienceDetail){
		try {
			experienceDetail = experianceDetailService.addExperianDetail(experienceDetail);
			return new ResponseEntity<Object>(experienceDetail,HttpStatus.OK);
			
		}catch (Exception e) {
			// TODO: handle exception
			return new ResponseEntity<Object>(e,HttpStatus.OK);
		}
		
	}
	@Autowired
	ExperianceDetailService experianceDetailService;
}
