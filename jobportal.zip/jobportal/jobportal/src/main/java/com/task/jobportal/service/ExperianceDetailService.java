package com.task.jobportal.service;

import com.task.jobportal.entity.ExperienceDetail;

public interface ExperianceDetailService {

	public ExperienceDetail addExperianDetail(ExperienceDetail experienceDetail);
}
