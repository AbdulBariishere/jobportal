package com.task.jobportal.service;

import com.task.jobportal.entity.UserAccount;

public interface UserAccountService {
	
	public UserAccount save(UserAccount userAccount);

}
