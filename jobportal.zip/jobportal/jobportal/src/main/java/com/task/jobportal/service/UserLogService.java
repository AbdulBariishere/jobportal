package com.task.jobportal.service;

import com.task.jobportal.entity.UserLog;

public interface UserLogService {

public UserLog addUserLog(UserLog userLog);

}
